$(function() {
  function ajax() {
    $.ajax({
      url: "https://v1.hitokoto.cn/",
      type: "GET",
      data: {
        c: "a"
      },
      dataType: "json",
      success: function(data) {
        // console.log(data);

        $(".one").html(data.hitokoto);
        $(".ones").html("--" + data.from);
      }
    });
  }

  setInterval(function() {
    ajax();
    $(".jq").animate({ top: "20px", opacity: "0.3" }, "slow");
    $(".jq").animate({ top: "0px", opacity: "1" }, "slow");
  }, 3000);
});
