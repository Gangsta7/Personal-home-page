import { Menu, Icon } from "antd";
import React from "react";
import "antd/dist/antd.css";

const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;

class Head extends React.Component {
  state = {
    current: "mail"
  };

  // componentDidMount() {
  //   window.addEventListener("scroll", this.handleScroll.bind(this)); //监听滚动
  //   // window.addEventListener("resize", this.handleResize.bind(this)); //监听窗口大小改变
  // }

  // componentWillUnmount() {
  //   //一定要最后移除监听器，以防多个组件之间导致this的指向紊乱
  //   window.removeEventListener("scroll", this.handleScroll.bind(this));
  //   // window.removeEventListener("resize", this.handleResize.bind(this));
  // }

  // handleScroll = e => {
  //   // if (e.srcElement.scrollingElement.scrollTop >= "160") {
  //   //   document.getElementById("strat-2").style.opacity = "1";
  //   // }

  //   // else if (e.srcElement.scrollingElement.scrollTop >= "90") {
  //   //   document.getElementById("strat-2").style.opacity = "1";
  //   // } else if (e.srcElement.scrollingElement.scrollTop >= "240") {
  //   //   document.getElementById("strat-3").style.opacity = "1";
  //   // } else if (e.srcElement.scrollingElement.scrollTop >= "500") {
  //   //   document.getElementById("strat-4").style.opacity = "1";
  //   // }

  //   console.log(
  //     // document.getElementById("acc").offsetTop,
  //     // document.getElementById("ac").offsetTop,
  //     // document.getElementById("acc").offsetTop
  //     // document.getElementById("acc").getBoundingClientRect().top
  //     e.srcElement.scrollingElement.scrollTop
  //     // e.srcElement.scrollingElement.scrollHeight
  //   );
  //   //e.srcElement.scrollingElement.scrollTop为距离滚动条顶部高度
  //   // e.srcElement.scrollingElement.scrollHeight为整个文档高度
  // };

  // handleResize = e => {
  //   console.log("浏览器窗口大小改变事件", e.target.innerWidth);
  // };

  handleClick = e => {
    console.log("click ", e);
    this.setState({
      current: e.key
    });
  };

  render() {
    return (
      <Menu
        onClick={this.handleClick}
        selectedKeys={[this.state.current]}
        mode="horizontal"
      >
        <Menu.Item key="mail">
          <a href="#a1" />
          <Icon type="smile" />
          我的
        </Menu.Item>
        <Menu.Item key="app">
          <a href="#a2" />
          <Icon type="appstore" />
          成长路程
        </Menu.Item>
        <SubMenu
          title={
            <span className="submenu-title-wrapper">
              <Icon type="heart" />
              个人作品
            </span>
          }
        >
          <MenuItemGroup title="前端">
            <Menu.Item key="setting:1">
              <Icon type="folder" />
              作品集
              <a href="#a3" />
            </Menu.Item>
          </MenuItemGroup>
          <MenuItemGroup title="摄影">
            <Menu.Item key="setting:3">
              <Icon type="picture" />
              照片墙
              <a href="#a6" />
            </Menu.Item>
          </MenuItemGroup>
        </SubMenu>
        <Menu.Item key="alipay">
          <a href="#a4" />
          <Icon type="mail" />
          联系方式
        </Menu.Item>
      </Menu>
    );
  }
}

export default Head;
