import React from "react";
import "antd/dist/antd.css";
import "./styles.css";
import { BackTop } from "antd";
import Button from "@material-ui/core/Button";
import Input from "@material-ui/core/Input";
import Paper from "@material-ui/core/Paper";
import withStyles from "@material-ui/core/styles/withStyles";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import Avatar from "@material-ui/core/Avatar";
import Area from "./Area";
import Oneword from "./oneword";

const styles = theme => ({
  paper: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: `${theme.spacing.unit * 2}px ${theme.spacing.unit * 3}px ${theme
      .spacing.unit * 3}px`
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing.unit
  },
  // 提交按钮
  submit: {
    marginTop: theme.spacing.unit * 3
    // justify="right"
  },
  text: {
    marginTop: theme.spacing.unit * 5
  },
  bigAvatar: {
    margin: 10,
    width: 60,
    height: 60
  }
});

var jso = [];

function foot(props) {
  const { classes } = props;
  function json() {
    var parArr = {};

    const a = document.getElementById("email").value;
    const b = document.getElementById("text").value;
    const c = document.getElementById("area").value;
    parArr.email = a;
    parArr.name = b;
    parArr.text = c;
    // const params = JSON.stringify(parArr);
    // text,json.push(params);
    jso.push(parArr);
    console.log(parArr);
    console.log(jso);
    return jso;
  }
  function Overo(sty, e) {
    document.getElementById("wec").style.opacity = "0.2";
    // console.log("The link was clicked.");
  }

  function Outo(e) {
    document.getElementById("wec").style.opacity = "1";
    // console.log("The link was clicked.");
  }

  function Overt(sty, e) {
    document.getElementById("github").style.opacity = "0.2";
    // console.log("The link was clicked.");
  }

  function Outt(e) {
    document.getElementById("github").style.opacity = "1";
    // console.log("The link was clicked.");
  }

  function Overth(sty, e) {
    document.getElementById("codesandbox").style.opacity = "0.2";
    // console.log("The link was clicked.");
  }

  function Outth(e) {
    document.getElementById("codesandbox").style.opacity = "1";
    // console.log("The link was clicked.");
  }

  return (
    <Paper className={classes.paper}>
      <Grid container spacing={24}>
        <Grid item xs={12} sm={6}>
          <form className={classes.form}>
            <FormControl margin="normal" fullWidth>
              <InputLabel htmlFor="email">电子邮箱</InputLabel>
              <Input id="email" name="email" autoComplete="email" />
            </FormControl>
            <FormControl margin="normal" fullWidth>
              <InputLabel htmlFor="title">姓名</InputLabel>
              <Input
                name="text"
                type="text"
                id="text"
                autoComplete="current-password"
              />
            </FormControl>
            <Area className="ar" />
            <Button
              // type="submit"
              variant="contained"
              color="primary"
              className={classes.submit}
              onClick={json}
            >
              提交
            </Button>
          </form>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography component="h2" variant="h5" className={classes.text}>
            如果你有好的想法或者建议的话，欢迎随时联系我！
          </Typography>
          <Typography component="h2" variant="h5" className={classes.text}>
            我将尽快回复你。
          </Typography>
          <Grid
            className={classes.text}
            container
            justify="center"
            spacing={16}
          >
            <Grid item>
              <Button
                style={{ backgroundColor: "white" }}
                onMouseOver={Overo}
                onMouseOut={Outo}
                id="wec"
              >
                <Avatar
                  alt="wechat"
                  src="https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2715149189,3830220427&fm=26&gp=0.jpg"
                  className={classes.bigAvatar}
                />
              </Button>
            </Grid>

            <Grid item>
              <Button
                style={{ backgroundColor: "white" }}
                onMouseOver={Overt}
                onMouseOut={Outt}
                href="https://github.com/Gangsta7"
                target="_blank"
                id="github"
              >
                <Avatar
                  alt="github"
                  src="https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2628554500,954322324&fm=26&gp=0.jpg"
                  className={classes.bigAvatar}
                />
              </Button>
            </Grid>
            <Grid item>
              <Button
                style={{ backgroundColor: "white" }}
                onMouseOver={Overth}
                onMouseOut={Outth}
                href="https://codepen.io/gangsta777/"
                target="_blank"
                id="codesandbox"
              >
                <Avatar
                  alt="codepen"
                  src="https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2590954006,2166048563&fm=26&gp=0.jpg"
                  className={classes.bigAvatar}
                />
              </Button>
            </Grid>
          </Grid>
          <Grid>
            <Oneword />
          </Grid>
        </Grid>
      </Grid>
      <div>
        <BackTop visibilityHeight={500}>
          <div className="ant-back-top-inner">UP</div>
        </BackTop>
      </div>
      ,
    </Paper>
  );
}

export default withStyles(styles)(foot);
