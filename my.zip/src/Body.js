import React from "react";
// import "./styles.css";
import { Card, Button } from "antd";
import { Divider } from "antd";
import { Layout } from "antd";
import { Carousel } from "antd";
import { Timeline, Icon } from "antd";
import { Row, Col } from "antd";
import { Avatar } from "antd";
import { Typography } from "antd";
import { Tag } from "antd";
import Texty from "rc-texty";
import Pic from "./picture";
import "rc-texty/assets/index.css";
import { Parallax } from "rc-scroll-anim";
const { Paragraph, Title } = Typography;
const { Meta } = Card;
const { Content } = Layout;

function My() {
  return (
    <div className="mys">
      <Row className="row">
        <Col span={12} offset={6} style={{ textAlign: "center" }}>
          <Row>
            <Col>
              <Avatar
                size={100}
                src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=383617263,898169512&fm=26&gp=0.jpg"
              />
            </Col>
            <Col span={32}>
              <Typography>
                <Texty
                  style={{ color: "white" }}
                  className="aboutme"
                  mode={"random"}
                >
                  小 猪乔治
                </Texty>
                <Texty style={{ color: "white" }} delay={550} mode={"random"}>
                  一 只快乐的猪
                </Texty>
              </Typography>
            </Col>
          </Row>
        </Col>
      </Row>
    </div>
  );
}

function Start() {
  return (
    <Timeline>
      <Timeline.Item
        dot={<Icon type="clock-circle-o" style={{ fontSize: "16px" }} />}
        color="blue"
      >
        <Row type="flex" justify="space-around" id="strat-1">
          <Col xs={24} sm={10} md={12}>
            <Parallax
              animation={{ x: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{
                transform: "translateX(-100px)",
                opacity: 0
              }}
            >
              <h2>中山大学南方学院</h2>
              <h3>本科 计算机科学与技术</h3>
              <h4 style={{ opacity: "0.5" }}>2016-至今</h4>
            </Parallax>
          </Col>

          <Col xs={24} sm={10} md={8}>
            <Parallax
              animation={{ y: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateY(+100px)", opacity: 0 }}
            >
              <img
                src="http://www.nfu.edu.cn/Public/Uploads/images/2016-05-03/small_5728495e977ae.jpg"
                width="100%"
                height="100%"
              />
            </Parallax>
          </Col>
        </Row>
      </Timeline.Item>
      <Timeline.Item
        dot={<Icon type="heart" style={{ fontSize: "16px" }} />}
        color="red"
      >
        <Row type="flex" justify="space-around" id="strat-2">
          <Col xs={24} sm={10} md={12}>
            <Parallax
              animation={{ x: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateX(-100px)", opacity: 0 }}
            >
              <h2>初识前端</h2>
              <h3>HTML5+CSS3</h3>
              <h4 style={{ opacity: "0.5" }}>2018</h4>
            </Parallax>
          </Col>
          <Col xs={24} sm={10} md={8}>
            <Parallax
              animation={{ y: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateY(+100px)", opacity: 0 }}
            >
              <img
                src="https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=324094824,2200004931&fm=26&gp=0.jpg"
                width="100%"
                height="100%"
              />
            </Parallax>
          </Col>
        </Row>
      </Timeline.Item>
      <Timeline.Item
        dot={<Icon type="team" style={{ fontSize: "16px" }} />}
        color="blue"
      >
        <Row type="flex" justify="space-around" id="strat-3">
          <Col xs={24} sm={10} md={12}>
            <Parallax
              animation={{ x: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateX(-100px)", opacity: 0 }}
            >
              <h2>校园经历</h2>
              <h3>加入漫协、留任外联部部长</h3>
              <h4 style={{ opacity: "0.5" }}>2016-2018</h4>
            </Parallax>
          </Col>
          <Col xs={24} sm={10} md={8}>
            <Parallax
              animation={{ y: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateY(+100px)", opacity: 0 }}
            >
              <img
                src="http://m.qpic.cn/psb?/V11BALj63ODKdb/jvbQZ4G4ZEkucP6kpAZgzX7rFoVLoh1hIJH.GPkJNLU!/b/dDYBAAAAAAAA&bo=YAlABnAXoA8RCdk!&rf=viewer_4"
                width="100%"
                height="100%"
              />
            </Parallax>
          </Col>
        </Row>
      </Timeline.Item>
      <Timeline.Item
        dot={<Icon type="like" style={{ fontSize: "16px" }} />}
        color="red"
      >
        <Row type="flex" justify="space-around" id="strat-4">
          <Col xs={24} sm={10} md={12}>
            <Parallax
              animation={{ x: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateX(-100px)", opacity: 0 }}
            >
              <h2>摄影</h2>
              <h3>喜欢拍摄风景</h3>
            </Parallax>
          </Col>
          <Col xs={24} sm={10} md={8}>
            <Parallax
              animation={{ y: 0, opacity: 1, playScale: [0.3, 0.7] }}
              style={{ transform: "translateY(+100px)", opacity: 0 }}
            >
              <img
                src="http://b145.photo.store.qq.com/psb?/V11BALj624XYPo/DeceA1LtQ88HjqdaQrSRpPQh9bWcZi9mb9xiCmH978Q!/b/dJEAAAAAAAAA&amp;bo=gAcABYAHAAURECc!&rf=viewer_311"
                width="100%"
                height="100%"
              />
            </Parallax>
          </Col>
        </Row>
      </Timeline.Item>
      <Timeline.Item
        dot={<Icon type="idcard" style={{ fontSize: "16px" }} />}
      />
    </Timeline>
  );
}

function Word() {
  return (
    <div>
      <Divider id="a4">作品集</Divider>
      <Row type="flex" justify="space-around">
        <Col
          xs={20}
          sm={10}
          md={10}
          // style={{
          //   marginBottom: "16px"
          // }}
        >
          <Card
            // style={{ width: 350 }}
            cover={
              <img
                height={"280px"}
                alt="example"
                src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=852522310,2521654089&fm=26&gp=0.jpg"
              />
            }
          >
            <Button
              className="chrom"
              target="_blank"
              href="https://codepen.io/gangsta777/pen/vMjMNj"
            >
              <Icon type="chrome" spin style={{ fontSize: "30px" }} />
            </Button>
            <Meta
              avatar={<Icon type="codepen" style={{ fontSize: "50px" }} />}
              title="Code Pen"
              description="弹幕功能"
            />
          </Card>
          <Row>
            <Col className="tag">
              <Tag color="red">HTML5</Tag>
              <Tag color="green">CSS3</Tag>
              <Tag color="blue">JS</Tag>
              <Tag color="purple">BootStrap4</Tag>
            </Col>
          </Row>
        </Col>
        <Col xs={20} sm={10} md={10}>
          <Card
            cover={
              <img
                height={"280px"}
                alt="example"
                src="https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2614718858,1523566857&fm=26&gp=0.jpg"
              />
            }
          >
            <Button
              className="chrom"
              target="_blank"
              href="https://xlnmwkjkpz.codesandbox.io/"
            >
              <Icon type="chrome" spin style={{ fontSize: "30px" }} />
            </Button>
            <Meta
              avatar={
                <Icon type="code-sandbox" style={{ fontSize: "50px" }} />
                // <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
              }
              title="Code Sandbox"
              description="个人网页"
            />
          </Card>
          <Row>
            <Col className="tag">
              <Tag color="red">HTML5</Tag>
              <Tag color="green">CSS3</Tag>
              <Tag color="blue">JS</Tag>
              <Tag color="blue">React</Tag>
            </Col>
          </Row>
        </Col>
      </Row>
      <Divider id="a6">照片墙</Divider>
      <Pic />
    </div>
  );
}

class Body extends React.Component {
  render() {
    return (
      <Layout style={{ background: "white" }}>
        <Divider dashed orientation="left" id="a1">
          我的
        </Divider>
        <Content>
          <My />
        </Content>
        <Divider dashed orientation="left" id="a2">
          成长路程
        </Divider>
        <Content>
          <div className="sta">
            <Start />
          </div>
        </Content>
        <Divider dashed orientation="left" id="a3">
          个人作品
        </Divider>
        <Content>
          <Word />
        </Content>
      </Layout>
    );
  }
}

export default Body;
