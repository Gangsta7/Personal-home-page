import React from "react";
import ReactDOM from "react-dom";
import "antd/dist/antd.css";
import "./index.css";
import { BackTop } from "antd";

ReactDOM.render(
  <div>
    <BackTop visibilityHeight={10000}>
      <div className="ant-back-top-inner">UP</div>
    </BackTop>
    {/* Scroll down to see the bottom-right
    <strong style={{ color: "#1088e9" }}> blue </strong>
    button. */}
  </div>,
  document.getElementById("backtop")
);
