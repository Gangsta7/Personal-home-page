import React from "react";
import ReactDOM from "react-dom";
import { Icon, Layout } from "antd";
import "antd/dist/antd.css";
import { Divider } from "antd";
import Head from "./head";
import Foot from "./foot";
import Body from "./Body";
import "./styles.css";

const { Header, Content, Footer } = Layout;

function App() {
  return (
    <div className="App">
      <Layout>
        <Header
          className="head"
          style={{
            background: "white"
          }}
        >
          <Head />
        </Header>
        <Content className="cont" style={{ background: "white" }}>
          <Body />
        </Content>
        <Footer style={{ background: "white", paddingBottom: "7px" }}>
          <Divider dashed orientation="left" id="a4">
            联系方式
          </Divider>
          <Foot />
        </Footer>
        <Footer style={{ background: "white", textAlign: "center" }}>
          <Icon type="copyright" /> 2019
        </Footer>
      </Layout>
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
