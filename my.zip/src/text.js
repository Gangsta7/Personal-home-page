import Foot from "./foot";
import React from "react";

class Head extends React.Component {
  componentDidMount() {
    console.log('1')
  }
  render(){
    return(
      <Foot/>
      console.log(i)
     
    )
  }
}
 

