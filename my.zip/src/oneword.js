import React from "react";
import "./styles.css";

function oneword() {
  return (
    <div style={{ marginTop: "26px" }} className="jq">
      <span className="iconfont icon-ziyuanldpi1" />
      <h1 className="one" style={{ padding: "0 15px" }} />
      <span
        className="iconfont icon-ziyuanldpi"
        style={{ float: "right", paddingTop: "22px" }}
      />
      <h3 className="ones" style={{ textAlign: "right" }} />
    </div>
  );
}

export default oneword;
