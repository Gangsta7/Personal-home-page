import React from "react";

import { Row, Col, Icon, Button } from "antd";
import "./styles.css";

export default class picture extends React.Component {
  componentDidMount(e) {
    window.addEventListener("resize", this.handleResize.bind(this)); //监听窗口大小改变
  }

  componentWillUnmount() {
    //一定要最后移除监听器，以防多个组件之间导致this的指向紊乱
    window.removeEventListener("resize", this.handleResize.bind(this));
  }

  // bd = e => {
  //   if (e.target.innerWidth <= "650") {
  //     document.getElementById("picbox").style.height = 250 + "px";
  //   }
  // };

  handleResize = e => {
    if (e.target.innerWidth >= "780") {
      document.getElementById("picbox").style.height = 450 + "px";
    } else {
      document.getElementById("picbox").style.height = 250 + "px";
    }
    // console.log(
    //   document.getElementById("picbox").style.height,
    //   e.target.innerWidth
    // );
  };

  close = e => {
    document.getElementById("picrow").style.display = "none";
    document.getElementById("picbox").style.display = "none";
    document.getElementById("clo").style.display = "none";
    // console.log("hello");
  };

  picbox(id, e) {
    var a = document.getElementById(id);
    document.getElementById("picrow").style.display = "block";
    document.getElementById("picbox").style.display = "block";
    document.getElementById("clo").style.display = "block";
    document.getElementById("pitch1").src = a.src;
    // console.log(document.getElementById("picbox"));
    // console.log(id);
    // console.log(a.src);
  }

  render() {
    return (
      <div>
        <div id="picrow" />
        <Row type="flex" juBstify="center">
          <Button id="clo" shape="circle" onClick={this.close}>
            <Icon type="close" />
          </Button>
          <Col xs={16} sm={14} md={14} id="picbox">
            <img id="pitch1" width={"100%"} height={"100%"} />{" "}
          </Col>
        </Row>
        <Row type="flex" justify="space-around" className="pi">
          <Col xs={11} sm={8} md={8} className="p1">
            {/* <button onClick={this.picbox.bind(this, "p1")}> */}
            <img
              id="p1"
              src="http://m.qpic.cn/psb?/V11BALj63ODKdb/.0zS5gc9oxtWy83Fqo0eow*s6RB7YROCjgon.rwxbMI!/b/dIMAAAAAAAAA&bo=YAlABnAXoA8RGck!&rf=viewer_4"
              width={"100%"}
              height={"100%"}
              onClick={this.picbox.bind(this, "p1")}
            />
            {/* </button> */}
          </Col>
          <Col xs={12} sm={7} md={7} className="p2">
            <img
              id="p2"
              src="http://m.qpic.cn/psb?/V11BALj63ODKdb/iu4kCzwqdo4HJY0VZSU8GYRW6Un1t7xW8o7DazBhPeU!/b/dL4AAAAAAAAA&bo=YAlABnAXoA8RGck!&rf=viewer_4"
              width={"100%"}
              height={"100%"}
              onClick={this.picbox.bind(this, "p2")}
            />
          </Col>
          <Col xs={12} sm={8} md={8} className="p3">
            <img
              id="p3"
              src="http://m.qpic.cn/psb?/V11BALj63ODKdb/H2I*Csfk8ioSGgXMV0AQR7QV.qsa*VDY0mb7bp88*Cs!/b/dL4AAAAAAAAA&bo=YAlABnAXoA8RKfk!&rf=viewer_4"
              width={"100%"}
              height={"100%"}
              onClick={this.picbox.bind(this, "p3")}
            />
          </Col>
          <Col xs={11} sm={8} md={8} className="p4">
            <img
              id="p4"
              src="http://m.qpic.cn/psb?/V11BALj63ODKdb/i64wVBpK32i5kt37CzvmOcdDNxV.ynQGZei04V9v.HA!/b/dL8AAAAAAAAA&bo=YAlABnAXoA8ROek!&rf=viewer_4"
              width={"100%"}
              height={"100%"}
              onClick={this.picbox.bind(this, "p4")}
            />
          </Col>
          <Col xs={11} sm={7} md={7} className="p6">
            <img
              id="p5"
              src="http://m.qpic.cn/psb?/V11BALj63ODKdb/705aOEYHxCwGL8RQvgesMe0vybpilZFVK47wq*sLHUI!/b/dLYAAAAAAAAA&bo=YAlABnAXoA8RKfk!&rf=viewer_4"
              width={"100%"}
              height={"100%"}
              onClick={this.picbox.bind(this, "p5")}
            />
          </Col>
          <Col xs={12} sm={8} md={8} className="p5">
            <img
              id="p6"
              src="http://m.qpic.cn/psb?/V11BALj63ODKdb/wk*gCzeiU8HTKaKFA.bi.DXKKMIVusXwiTIGJwLwkys!/b/dFIBAAAAAAAA&bo=YAlABnAXoA8RGck!&rf=viewer_4"
              width={"100%"}
              height={"100%"}
              onClick={this.picbox.bind(this, "p6")}
            />
          </Col>
        </Row>
      </div>
    );
  }
}
