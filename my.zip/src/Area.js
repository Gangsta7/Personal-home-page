import React from "react";
import { Input } from "antd";

const { TextArea } = Input;

function Area() {
  return <TextArea rows={9} id="area" placeholder="请输入你想告诉我的信息" />;
}

export default Area;
